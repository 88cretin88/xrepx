# -*- coding: utf-8 -*-

# To be used just when MyQR is not installed

from MyQR.terminal import main

main()